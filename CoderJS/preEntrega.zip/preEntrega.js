

const buscador = $ ("#bs");




$("#boton").click(function() {

    $.ajax({
            url: "json/json.json",
            dataType: "json",
            success: function (response) {
                for (x of response){
                    if( buscador.val() == x.dni){
                        $(".insertar").append(`<p> ${x.name} </p>`);
                
                    }
                }
                
            }
        });


    
})



























